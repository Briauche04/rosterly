export type Lang = 'he' | 'en' | 'ru';

export const STR: Record<Lang, any> = {
  he: {
    dir: 'rtl',
    rosterly: 'Rosterly',
    tagline: 'נהל משמרות וצוות — בפשטות.',
    ctaStart: 'הגשת משמרות', // was "התחל עכשיו"
    features: 'מאפיינים',
    tutorials: 'מדריכים',
    forum: 'פורום פנימי',
    team: 'צוות',
    login: 'להתחבר', // was "כניסה"
    empty: 'בקרוב נוסיף כאן תוכן.',
    hero_sub: 'כלי נקי ומדויק לניהול זמינות, שיבוץ ותקשורת צוותית.',
    cards: [
      ['הגשת זמינות', 'תקופת הגשה א׳–ג׳ 09:00 עם תזכורות חכמות.'],
      ['מחולל משמרות', 'שיבוץ לפי תפקיד, יעד שעות או פריון.'],
      ['פורום בקשות', 'ביטול/החלפה, קבצים והודעות לצוות הנהלה.']
    ]
  },

  en: {
    dir: 'ltr',
    rosterly: 'Rosterly',
    tagline: 'Schedule & team management — made simple.',
    ctaStart: 'Submit shifts',
    features: 'Features',
    tutorials: 'Tutorials',
    forum: 'Team Forum',
    team: 'Team',
    login: 'Log in',
    empty: 'We will add content here soon.',
    hero_sub: 'A clean, precise tool for availability, auto-rosters and team comms.',
    cards: [
      ['Submit availability', 'Submit your shift availability with smart reminders.'],
      ['Shift generator', 'Assign shifts by role, target hours, or efficiency.'],
      ['Request forum', 'Swap or cancel shifts, share files and communicate with your team.']
    ]
  },

  ru: {
    dir: 'ltr',
    rosterly: 'Rosterly',
    tagline: 'Простое управление сменами и командой.',
    ctaStart: 'Подать смены',
    features: 'Возможности',
    tutorials: 'Инструкции',
    forum: 'Форум команды',
    team: 'Команда',
    login: 'Войти',
    empty: 'Скоро здесь появится контент.',
    hero_sub: 'Аккуратный инструмент для доступности, авто-графика и коммуникаций.',
    cards: [
      ['Отправка доступности', 'Период подачи с уведомлениями.'],
      ['Генератор смен', 'Распределение по ролям или целям.'],
      ['Форум запросов', 'Отмена, обмен и сообщения для команды.']
    ]
  }
};

export function useLang(q:any):Lang{const l=(q?.lang??'he').toString().toLowerCase();return(l==='en'||l==='ru')?l:'he';}
