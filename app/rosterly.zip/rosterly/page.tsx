import { Header, Footer } from "./layout";
import { STR, useLang } from "./i18n";

export default function Page({ searchParams }: { searchParams: any }) {
  const lang = useLang(searchParams);
  const t = STR[lang];

  return (
    <div className={t.dir === "rtl" ? "rtl" : ""}>
      <Header lang={lang} />

      <section className="hero">
        <div className="container hero-layout">
          {/* LEFT: text */}
          <div className="hero-text">
            <h1 className="title">{t.tagline}</h1>
            <p className="subtitle">{t.hero_sub}</p>

            <div className="cta">
              <a className="btn-primary" href={`/submit?lang=${lang}`}>
                {t.ctaStart}
              </a>
            </div>

            <div className="cards" id="features" style={{ marginTop: 28 }}>
              {t.cards?.map((c: any, i: number) => (
                <div key={i} className="card">
                  <h3 style={{ margin: "0 0 6px 0" }}>{c[0]}</h3>
                  <p style={{ margin: 0, color: "#555" }}>{c[1]}</p>
                </div>
              ))}
            </div>
          </div>

          {/* RIGHT: logo area (floats to the right edge of hero) */}
          <div className="logo-area" aria-hidden>
            <div className="logo-wrap">
              <img
                src="/rosterly/logos/rosterly-logo.png"
                alt="Rosterly logo"
                width={320}
                height="auto"
              />
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
